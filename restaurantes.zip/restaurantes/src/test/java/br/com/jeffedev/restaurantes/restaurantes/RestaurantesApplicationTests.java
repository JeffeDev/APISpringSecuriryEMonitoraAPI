package br.com.jeffedev.restaurantes.restaurantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
